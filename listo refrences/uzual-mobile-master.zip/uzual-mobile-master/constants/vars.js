export const POLL_INTERVAL = 10000;
export const MOOD_REMINDER = 'MOOD_REMINDER';
